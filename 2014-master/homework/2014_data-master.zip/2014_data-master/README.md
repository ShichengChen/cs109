## CS109 Data Science

This is the data directory for the CS109 Data Science course.  

The course website can be viewed here: [http://cs109.github.io/2014](http://cs109.github.io/2014)
